cd '/home/william/nC_projects/PN2RS/generatedNEURON'
/usr/local//bin/nrngui PN2RS.hoc